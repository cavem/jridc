<?php
class MainAction extends SaleadminAction{
    public function index(){
    	$this->display();
	}
}
?>