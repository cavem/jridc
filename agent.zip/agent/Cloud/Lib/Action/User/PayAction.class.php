<?php
//充值管理
class PayAction extends MainuserAction{
	public function index(){
		$this->display();
	}
	//在线支付
	public function dopay(){
		
		
		
		
	}
}
?>