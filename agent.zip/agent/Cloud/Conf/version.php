<?php
return array(  
 	'VERSION'=>'201606171200',
);  
?>