<?php
return array(
	'DEFAULT_THEME'         =>'Default',    //默认模板
    'TMPL_ACTION_ERROR' => 'Common:jump',//错误提示页面
    'TMPL_ACTION_SUCCESS' => 'Common:jump',//正确提示页面
	'VAR_FILTERS'=>'stripslashes,strip_tags',//全局参数过滤2016-3-25
);
?>