<?php
return array(
   	'API_HOST'=>'http://www.gwidc.com/api',//对接主机
	'API_MANAGE_LOGIN'=>'http://mghgm.17b.net/manage/login/agentlogin',//管理登陆地址
	'api_logout_url'=>'http://www.17b.net/user/cloud/index',//退出返回地址
	'APIUSERNAME'=>'4735078@qq.com',
	'APIKEY'=>'5be0ab1a90e28a4b65387fb11e73ced2',
);
?>