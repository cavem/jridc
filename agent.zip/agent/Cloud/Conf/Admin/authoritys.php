<?php
$authoritys = array();
$authoritys['no']['Main']['index'] = 1;
$authoritys['no']['Ajax'] = 1;
$authoritys['no']['Card']['checkcard'] = 1;
$authoritys['no']['Card']['cardcode'] = 1;
$authoritys['no']['System']['adminpasswd'] = 1;
$authoritys['no']['Cloud']['vmstate'] = 1;
$authoritys['no']['Cloud']['cloudcheck'] = 1;
$authoritys['no']['Cloudconfig']['iptype'] = 1;
$authoritys['no']['Cloudconfig']['storagelist'] = 1;
$authoritys['no']['Beian']['state'] = 1;
$authoritys['no']['Beian']['selectcode'] = 1;
$authoritys['no']['Beian']['postcurl'] = 1;
$authoritys['no']['Beian']['config'] = 1;
$authoritys['no']['Setting']['setfapiao'] = 1;













