<?php
return array(
 	'CHECKIP'=>'',
);
?>