<?php
return array(
	'UPDATEURL'=>'http://agent.update.95vdc.com:30753/index.php/Version',
	'UPDATEUSERNAME'=>'agentQCYMAN4nz8rutbji',
	'UPDATEPASSWORD'=>'eIBubkWAWXFu9FNMIwQBN9JRU',
);
?>