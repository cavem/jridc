<?php
return array(//用于接收工单提醒
    'support_email'=>'573992533@qq.com',//邮箱
    'support_tel'=>'18913477088',//手机（短信提醒）
	'domainemai'=>'573992533@qq.com',//白名单提醒邮箱
);
?>