<?php
return array(  
    'DB_TYPE'=>'mysql',    
    'DB_HOST'=>'127.0.0.1',  
    'DB_NAME'=>'sqlyagent', 
    'DB_USER'=>'sqlyagent',  
    'DB_PWD'=>'is8nzNzbAiNfm0O',  
    'DB_PORT'=>'3306',  
    'DB_PREFIX'=>'cloud_', 
);  
?>