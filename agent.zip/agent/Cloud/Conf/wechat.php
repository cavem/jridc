<?php
return array(
	//工单进度通知
	"p6pedO7ih_-EZhItg9ALYi_XMqsqbULVvpXtKUkV3r4" => array(
			'first' =>  array(//首行
				'value' => '',
				'color' => '#fff'
			),
			'keyword1' => array(//工单号
				'value' => '',
				'color' => '#fff'
			),
			'keyword2' => array(//工单进度
				'value' => '',
				'color' => '#fff'
			),
			'keyword3' => array(//工单处理人
				'value' => '',
				'color' => '#fff'
			),
			'remark' => array(//备注
				'value' => '',
				'color' => '#fff'
			)
		),
	"bZ6x24-NBQ7JTzsOz2ljCpEGell5sJxEn41uTYCIr1Y" => array(
			'first' =>  array(
				'value' => '',
				'color' => '#FF0000'
			),
			'data1' => array(
				'value' => '',
				'color' => '#FF0000'
			),
			'data2' => array(
				'value' => '',
				'color' => '#FF0000'
			),
			'bak' => array(
					'value' => '',
					'color' => ''
			)
		),
	"Ztc4s4vkuZrSl-RjDCqF04_NiegAM7D1epr7R71xTuE"=>array(
			'data1' => array(
				'value' => '',
				'color' => '#FF0000'
			)
		)
);  
?>